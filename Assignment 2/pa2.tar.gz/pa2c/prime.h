//Computes and returns the square of a value n (n^2)
int square(int n);

//Checks whether a number n is prime
int isPrime(int n);
